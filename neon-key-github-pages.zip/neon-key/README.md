# NEON KEY — GitHub Pages

Gaming-style responsive Get Key + Verify Key frontend.

## Deploy

1. Create a public GitHub repository, for example `neon-key`.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then **Save**.
6. Wait for GitHub Pages to publish the site.

Your URL will normally look like:

`https://YOUR-USERNAME.github.io/neon-key/`

## Change Discord

Open `script.js` and replace:

`https://discord.gg/YOUR_INVITE`

with your real Discord invite.

## Important security note

This repository is a static GitHub Pages site. The included key system is intentionally a browser-only demo using `localStorage`.

Do NOT put:
- API secrets
- private tokens
- admin keys
- database credentials
- real authorization secrets

inside frontend JavaScript.

For a real key system, use a backend/API that:
1. creates keys server-side,
2. stores key status/expiry server-side,
3. verifies keys server-side,
4. rate-limits requests,
5. returns only the minimum verification result to the frontend.

The GitHub Pages frontend can then call that API with `fetch()`.
