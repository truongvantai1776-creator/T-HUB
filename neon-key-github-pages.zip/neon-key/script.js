// =====================
// NEON KEY CONFIG
// =====================
const DISCORD_URL = "https://discord.gg/YOUR_INVITE";

const KEY_STORAGE = "neon_demo_key";
const KEY_CREATED = "neon_demo_created";

// Demo-only key generator. Do NOT use client-side secrets for real authorization.
function randomPart(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return [...bytes].map(b => chars[b % chars.length]).join("");
}

function makeKey() {
  return `NEON-${randomPart()}-${randomPart()}-${randomPart()}`;
}

function setDiscordLinks() {
  document.querySelectorAll("#discordTop,#discordBottom").forEach(a => {
    a.href = DISCORD_URL;
  });
}

function showStatus(el, message, type = "") {
  el.textContent = message;
  el.className = `status ${type}`;
}

function generateKey() {
  const key = makeKey();
  localStorage.setItem(KEY_STORAGE, key);
  localStorage.setItem(KEY_CREATED, String(Date.now()));

  document.getElementById("generatedKey").value = key;
  showStatus(document.getElementById("getStatus"),
    "Key đã được tạo cho trình duyệt này. Đây là hệ thống demo.", "ok");
}

async function copyKey() {
  const value = document.getElementById("generatedKey").value;
  if (!value) {
    showToast("Hãy tạo key trước.");
    return;
  }
  try {
    await navigator.clipboard.writeText(value);
    showToast("Đã copy key.");
  } catch {
    showToast("Không thể copy tự động. Hãy copy thủ công.");
  }
}

function verifyKey() {
  const input = document.getElementById("verifyInput").value.trim().toUpperCase();
  const saved = localStorage.getItem(KEY_STORAGE);
  const status = document.getElementById("verifyStatus");

  if (!input) {
    showStatus(status, "Vui lòng nhập key.", "bad");
    return;
  }

  if (input === saved) {
    showStatus(status, "✓ Key hợp lệ trên trình duyệt này.", "ok");
  } else {
    showStatus(status, "✕ Key không hợp lệ hoặc chưa được tạo trên trình duyệt này.", "bad");
  }
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2200);
}

document.getElementById("generateBtn").addEventListener("click", generateKey);
document.getElementById("copyBtn").addEventListener("click", copyKey);
document.getElementById("verifyBtn").addEventListener("click", verifyKey);
document.getElementById("verifyInput").addEventListener("keydown", e => {
  if (e.key === "Enter") verifyKey();
});

setDiscordLinks();

const existing = localStorage.getItem(KEY_STORAGE);
if (existing) document.getElementById("generatedKey").value = existing;
