# T HUB

Website Get Key + Verify Key, giao diện gaming neon.

## Đưa lên GitHub Pages bằng điện thoại

1. Tạo repository mới trên GitHub, ví dụ `T-HUB`.
2. Upload 4 file:
   - `index.html`
   - `verify.html`
   - `style.css`
   - `script.js`
3. Vào **Settings → Pages**.
4. Chọn **Deploy from a branch** → branch `main` → folder `/ (root)` → Save.
5. Chờ GitHub Pages build xong rồi mở đường link Pages.

## Đổi link Discord
Mở `script.js`, tìm:
`alert("Hãy thay link Discord...")`
và thay phần xử lý nút Discord bằng link server của bạn.

## Lưu ý
Bản GitHub Pages này là hệ thống key phía trình duyệt. Key được lưu bằng localStorage, nên xóa dữ liệu trình duyệt hoặc đổi trình duyệt có thể tạo Device ID mới. Đây không phải backend chống gian lận. Nếu cần key thật sự được quản lý tập trung, cần thêm API/backend và database.
