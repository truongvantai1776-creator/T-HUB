const $=s=>document.querySelector(s);
function randomPart(n=4){const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(let i=0;i<n;i++)s+=chars[Math.floor(Math.random()*chars.length)];return s}
function getDeviceId(){
 let id=localStorage.getItem("thub_device_id");
 if(!id){id="DEV-"+crypto.randomUUID().replaceAll("-","").slice(0,12).toUpperCase();localStorage.setItem("thub_device_id",id)}
 return id;
}
function makeKey(){return `THUB-${randomPart()}-${randomPart()}-${randomPart()}`}
const device=getDeviceId();
if($("#deviceId")) $("#deviceId").textContent=device;
function showKey(data){
 $("#key").textContent=data.key;
 $("#expires").textContent="Expires: "+new Date(data.expires).toLocaleString();
 $("#keyBox").classList.remove("hidden");
}
$("#getKey")?.addEventListener("click",()=>{
 let data=JSON.parse(localStorage.getItem("thub_key_data")||"null");
 if(!data || Date.now()>data.expires || data.device!==device){
   data={key:makeKey(),device,expires:Date.now()+24*60*60*1000};
   localStorage.setItem("thub_key_data",JSON.stringify(data));
 }
 showKey(data);
});
$("#copy")?.addEventListener("click",async()=>{
 const k=$("#key").textContent;
 try{await navigator.clipboard.writeText(k);$("#copy").textContent="COPIED!"}
 catch{prompt("Copy your key:",k)}
 setTimeout(()=>$("#copy").textContent="COPY",1200);
});
$("#discord")?.addEventListener("click",e=>{
 e.preventDefault();
 alert("Hãy thay link Discord trong script.js bằng link server của bạn.");
});